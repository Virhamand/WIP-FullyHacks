ALTER TABLE `game_rounds` ADD COLUMN `aiCommentary` text DEFAULT NULL;
